
package com.dispatch.gateway;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.converter.Converter;
import org.springframework.http.HttpMethod;

import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.oauth2.jose.jws.MacAlgorithm;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.NimbusJwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class GatewaySecurityConfig {

    @Value("${app.jwt.secret}")
    private String secret;

    // JWT decoder - HS384
    @Bean
    public JwtDecoder jwtDecoder() {

        SecretKey key = new SecretKeySpec(
                secret.getBytes(StandardCharsets.UTF_8),
                "HmacSHA384"
        );

        return NimbusJwtDecoder.withSecretKey(key)
                .macAlgorithm(MacAlgorithm.HS384)
                .build();
    }

    // Security configuration
    @Bean
    public SecurityFilterChain securityFilterChain(
            HttpSecurity http) throws Exception {

        http
            .csrf(csrf -> csrf.disable())

            .cors(cors -> {})

            .sessionManagement(session ->
                session.sessionCreationPolicy(
                    SessionCreationPolicy.STATELESS
                )
            )

            .authorizeHttpRequests(auth -> auth

                // Login and registration are public
                .requestMatchers("/api/auth/**").permitAll()

                // Courier can upload scans
                .requestMatchers(
                    HttpMethod.POST,
                    "/api/scans"
                ).hasAuthority("ROLE_courier")

                // Operations reviewer can view scans
                .requestMatchers(
                    HttpMethod.GET,
                    "/api/scans",
                    "/api/scans/**"
                ).hasAuthority("ROLE_operator_reviewer")

                // Operations reviewer can view timelines
                .requestMatchers(
                    "/api/timeline/**"
                ).hasAuthority("ROLE_operator_reviewer")

                // Operations reviewer can review conflicts
                .requestMatchers(
                    "/api/conflicts/**"
                ).hasAuthority("ROLE_operator_reviewer")

                // Deny everything else
                .anyRequest().denyAll()
            )

            .oauth2ResourceServer(oauth2 ->
                oauth2.jwt(jwt ->
                    jwt.jwtAuthenticationConverter(
                        jwtAuthenticationConverter()
                    )
                )
            );

        return http.build();
    }

    // Read roles from JWT
    @Bean
    public Converter<Jwt, ? extends AbstractAuthenticationToken>
            jwtAuthenticationConverter() {

        return jwt -> {

            List<String> roles =
                    jwt.getClaimAsStringList("roles");

            var authorities = roles == null
                    ? List.<SimpleGrantedAuthority>of()
                    : roles.stream()
                        .map(role ->
                            new SimpleGrantedAuthority(
                                "ROLE_" + role
                            )
                        )
                        .collect(Collectors.toList());

            return new JwtAuthenticationToken(
                    jwt,
                    authorities,
                    jwt.getSubject()
            );
        };
    }
}
