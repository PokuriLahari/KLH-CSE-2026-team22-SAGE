
package com.dispatch.auth;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Set;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/auth")
public class AuthController {

    private final UserRepository repository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    public AuthController(
            UserRepository repository,
            PasswordEncoder passwordEncoder,
            JwtService jwtService) {

        this.repository = repository;
        this.passwordEncoder = passwordEncoder;
        this.jwtService = jwtService;
    }

    // REGISTER
    @PostMapping("/register")
    public ResponseEntity<?> register(
            @RequestBody RegisterRequest request) {

        // Validate registration details
        if (request.name == null || request.name.isBlank()
                || request.email == null || request.email.isBlank()
                || request.password == null
                || request.password.length() < 8) {

            return ResponseEntity.badRequest().body(
                Map.of(
                    "message",
                    "Enter a name, valid email, and password of at least 8 characters."
                )
            );
        }

        String email = request.email.trim().toLowerCase();

        // Check duplicate email
        if (repository.existsByEmail(email)) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(
                Map.of("message", "Email already registered.")
            );
        }

        // Validate selected role
        if (request.role == null || request.role.isBlank()) {
            return ResponseEntity.badRequest().body(
                Map.of("message", "Please select a role.")
            );
        }

        // Normalize role
        String role = request.role.trim()
                .toUpperCase()
                .replace(" ", "_")
                .replace("-", "_");

        // Map Operations Reviewer variations to one role
        if (role.equals("OPERATIONS_REVIEWER")
                || role.equals("OPERATIONSREVIEWER")
                || role.equals("OPERATOR_REVIEWER")
                || role.equals("OPERATORREVIEWER")) {

            role = "OPERATOR_REVIEWER";
        }

        // Only two roles are allowed
        Set<String> allowedRoles = Set.of(
            "COURIER",
            "OPERATOR_REVIEWER"
        );

        if (!allowedRoles.contains(role)) {
            return ResponseEntity.badRequest().body(
                Map.of(
                    "message",
                    "Invalid role. Select Courier or Operations Reviewer."
                )
            );
        }

        // Create user
        AppUser user = new AppUser();

        user.setName(request.name.trim());
        user.setEmail(email);
        user.setPassword(
            passwordEncoder.encode(request.password)
        );

        // Store normalized role
        user.setRole(role.toLowerCase());

        repository.save(user);

        return ResponseEntity.ok(
            Map.of(
                "message",
                "Registration successful. Please login."
            )
        );
    }

    // LOGIN
    @PostMapping("/login")
    public ResponseEntity<?> login(
            @RequestBody LoginRequest request) {

        if (request.email == null || request.password == null) {
            return ResponseEntity.badRequest().body(
                Map.of(
                    "message",
                    "Email and password are required."
                )
            );
        }

        String email = request.email.trim().toLowerCase();

        // Find user by email
        AppUser user = repository
                .findByEmail(email)
                .orElse(null);

        // Validate credentials
        if (user == null
                || !passwordEncoder.matches(
                    request.password,
                    user.getPassword())) {

            return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body(
                        Map.of(
                            "message",
                            "Invalid email or password."
                        )
                    );
        }

        // Normalize the existing user's role for the response
        String role = user.getRole()
                .trim()
                .toUpperCase()
                .replace(" ", "_")
                .replace("-", "_");

        if (role.equals("OPERATIONS_REVIEWER")
                || role.equals("OPERATIONSREVIEWER")
                || role.equals("OPERATORREVIEWER")) {

            role = "OPERATOR_REVIEWER";
        }

        // Generate JWT token
        String token = jwtService.generateToken(user);

        // Return login response
        return ResponseEntity.ok(
            Map.of(
                "token", token,
                "role", role,
                "name", user.getName()
            )
        );
    }

    // Registration request
    public static class RegisterRequest {
        public String name;
        public String email;
        public String password;
        public String role;
    }

    // Login request
    public static class LoginRequest {
        public String email;
        public String password;
    }
}
