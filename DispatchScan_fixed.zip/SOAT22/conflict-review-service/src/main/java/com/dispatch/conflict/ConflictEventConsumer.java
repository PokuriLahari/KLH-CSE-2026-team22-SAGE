
package com.dispatch.conflict;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class ConflictEventConsumer {

    private final ScanRecordRepository scanRepository;
    private final ShipmentConflictRepository conflictRepository;
    private final ObjectMapper objectMapper;

    public ConflictEventConsumer(
            ScanRecordRepository scanRepository,
            ShipmentConflictRepository conflictRepository,
            ObjectMapper objectMapper) {

        this.scanRepository = scanRepository;
        this.conflictRepository = conflictRepository;
        this.objectMapper = objectMapper;
    }

    @KafkaListener(
            topics = "soa.s06.t22.events",
            groupId = "conflict-review-group"
    )
    @Transactional
    public void consume(String message) throws Exception {

        JsonNode event = objectMapper.readTree(message);

        String eventId = event.path("eventId").asText("");
        String shipmentId = event.path("shipmentId").asText("");
        String deviceId = event.path("deviceId").asText("");
        long sequence = event.path("sequenceNumber").asLong(-1);
        String scanType = event.path("scanType").asText("");

        // Validate the event
        if (eventId.isBlank()
                || shipmentId.isBlank()
                || deviceId.isBlank()
                || sequence < 1
                || scanType.isBlank()) {

            throw new IllegalArgumentException(
                    "Invalid OfflineScanUploaded event");
        }

        // Ignore duplicate event delivery
        if (scanRepository.existsByEventId(eventId)) {
            System.out.println(
                    "Duplicate event ignored: " + eventId);
            return;
        }

        // Save the incoming scan
        ScanRecord record = new ScanRecord();
        record.setEventId(eventId);
        record.setShipmentId(shipmentId);
        record.setDeviceId(deviceId);
        record.setSequenceNumber(sequence);
        record.setScanType(scanType.toUpperCase());

        scanRepository.saveAndFlush(record);

        // Reconstruct history in device sequence order
        List<ScanRecord> history =
                scanRepository
                        .findByShipmentIdAndDeviceIdOrderBySequenceNumberAsc(
                                shipmentId, deviceId);

        // Recalculate conflicts using the complete history
        reviewHistory(history);

        System.out.println(
                "Reconstructed history for " + shipmentId);

        history.forEach(scan ->
                System.out.println(
                        scan.getSequenceNumber()
                                + " -> "
                                + scan.getScanType()));
    }

    private void reviewHistory(List<ScanRecord> history) {

        if (history == null || history.isEmpty()) {
            return;
        }

        boolean loadedSeen = false;

        Set<String> validConflictEventIds = new HashSet<>();

        for (ScanRecord scan : history) {

            String type = scan.getScanType();

            if ("LOADED".equalsIgnoreCase(type)) {
                loadedSeen = true;
            }

            if ("DELIVERED".equalsIgnoreCase(type)
                    && !loadedSeen) {

                validConflictEventIds.add(scan.getEventId());

                saveConflict(
                        scan,
                        "DELIVERED has no preceding LOADED scan "
                                + "in reconstructed device sequence");
            }
        }

        // Remove outdated conflicts when a late-arriving
        // scan makes the reconstructed sequence valid
        List<ShipmentConflict> existingConflicts =
                conflictRepository.findByShipmentId(
                        history.get(0).getShipmentId());

        String deviceId = history.get(0).getDeviceId();

        for (ShipmentConflict conflict : existingConflicts) {

            boolean sameDevice =
                    deviceId.equals(conflict.getDeviceId());

            boolean isReconciliationConflict =
                    conflict.getReason() != null
                            && conflict.getReason().startsWith(
                                    "DELIVERED has no preceding LOADED scan");

            if (sameDevice
                    && isReconciliationConflict
                    && !validConflictEventIds.contains(
                            conflict.getEventId())) {

                conflictRepository.delete(conflict);
            }
        }
    }

    private void saveConflict(
            ScanRecord scan, String reason) {

        ShipmentConflict conflict =
                conflictRepository.findByEventId(
                                scan.getEventId())
                        .orElseGet(ShipmentConflict::new);

        conflict.setEventId(scan.getEventId());
        conflict.setShipmentId(scan.getShipmentId());
        conflict.setDeviceId(scan.getDeviceId());
        conflict.setSequenceNumber(scan.getSequenceNumber());
        conflict.setScanType(scan.getScanType());
        conflict.setReason(reason);
        conflict.setStatus("QUARANTINED");

        conflictRepository.save(conflict);
    }
}
