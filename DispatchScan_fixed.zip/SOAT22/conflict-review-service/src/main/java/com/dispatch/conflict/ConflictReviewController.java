package com.dispatch.conflict;

import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/conflicts")
@CrossOrigin(origins = "*")
public class ConflictReviewController {

    private final ShipmentConflictRepository repository;

    public ConflictReviewController(ShipmentConflictRepository repository) {
        this.repository = repository;
    }

    @GetMapping
    public List<ShipmentConflict> getAllConflicts() {
        return repository.findAll();
    }

    @GetMapping("/shipment/{shipmentId}")
    public List<ShipmentConflict> getByShipment(
            @PathVariable String shipmentId) {
        return repository.findByShipmentId(shipmentId);
    }
}