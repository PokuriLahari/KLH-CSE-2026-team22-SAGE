package com.dispatch.conflict;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConflictReviewServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConflictReviewServiceApplication.class, args);
	}

}
