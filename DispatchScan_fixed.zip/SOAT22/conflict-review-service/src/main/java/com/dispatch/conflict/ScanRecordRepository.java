package com.dispatch.conflict;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ScanRecordRepository
        extends JpaRepository<ScanRecord, Long> {

    boolean existsByEventId(String eventId);

    List<ScanRecord>
        findByShipmentIdAndDeviceIdOrderBySequenceNumberAsc(
            String shipmentId,
            String deviceId);
}