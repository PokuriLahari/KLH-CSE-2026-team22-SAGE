
package com.dispatch.conflict;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface ShipmentConflictRepository
        extends JpaRepository<ShipmentConflict, Long> {

    boolean existsByEventId(String eventId);

    Optional<ShipmentConflict> findByEventId(String eventId);

    List<ShipmentConflict> findByShipmentId(String shipmentId);
}
