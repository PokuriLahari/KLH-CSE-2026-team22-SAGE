package com.dispatch.conflict;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConflictReviewServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
