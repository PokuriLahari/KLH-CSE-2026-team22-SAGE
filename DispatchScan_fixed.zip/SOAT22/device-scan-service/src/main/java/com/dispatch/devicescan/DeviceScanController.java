
package com.dispatch.devicescan;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
@CrossOrigin(origins = {
	    "http://localhost:5500",
	    "http://127.0.0.1:5500"
	})
@RestController
@RequestMapping("/api/scans")

public class DeviceScanController {

    private final DeviceScanRepository repository;
    private final ScanEventPublisher eventPublisher;

    public DeviceScanController(
            DeviceScanRepository repository,
            ScanEventPublisher eventPublisher) {
        this.repository = repository;
        this.eventPublisher = eventPublisher;
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public DeviceScan uploadScan(
            @RequestBody DeviceScan scan,
            @RequestHeader(
                    value = "X-Correlation-ID",
                    required = false) String correlationId) {

        if (scan.getShipmentId() == null
                || scan.getShipmentId().isBlank()) {
            throw new IllegalArgumentException("Shipment ID is required");
        }

        if (scan.getDeviceId() == null
                || scan.getDeviceId().isBlank()) {
            throw new IllegalArgumentException("Device ID is required");
        }

        if (scan.getSequenceNumber() == null
                || scan.getSequenceNumber() < 1) {
            throw new IllegalArgumentException(
                    "Sequence number must be positive");
        }

        if (scan.getScanType() == null
                || scan.getScanType().isBlank()) {
            throw new IllegalArgumentException("Scan type is required");
        }

        // Check whether this shipment scan already exists
        var existingScan =
                repository.findByShipmentIdAndDeviceIdAndSequenceNumber(
                        scan.getShipmentId(),
                        scan.getDeviceId(),
                        scan.getSequenceNumber());

        if (existingScan.isPresent()) {
            return existingScan.get();
        }

        scan.setReceivedTimestamp(LocalDateTime.now());

        DeviceScan saved = repository.save(scan);

        String correlation =
                correlationId == null || correlationId.isBlank()
                        ? UUID.randomUUID().toString()
                        : correlationId;

        eventPublisher.publish(saved, correlation);

        return saved;
    }

    @GetMapping
    public List<DeviceScan> getAllScans() {
        return repository.findAll();
    }

    @GetMapping("/shipment/{shipmentId}")
    public List<DeviceScan> getScansByShipment(
            @PathVariable String shipmentId) {
        return repository
                .findByShipmentIdOrderBySequenceNumberAsc(shipmentId);
    }
}
