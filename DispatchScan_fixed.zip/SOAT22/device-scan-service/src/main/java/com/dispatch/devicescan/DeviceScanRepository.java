
package com.dispatch.devicescan;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface DeviceScanRepository extends JpaRepository<DeviceScan, Long> {

    List<DeviceScan> findByShipmentIdOrderBySequenceNumberAsc(String shipmentId);

    Optional<DeviceScan> findByShipmentIdAndDeviceIdAndSequenceNumber(
            String shipmentId,
            String deviceId,
            Long sequenceNumber
    );
}
