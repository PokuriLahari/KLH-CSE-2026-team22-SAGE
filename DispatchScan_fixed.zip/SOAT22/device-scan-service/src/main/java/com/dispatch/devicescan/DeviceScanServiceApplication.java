package com.dispatch.devicescan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DeviceScanServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DeviceScanServiceApplication.class, args);
	}

}
