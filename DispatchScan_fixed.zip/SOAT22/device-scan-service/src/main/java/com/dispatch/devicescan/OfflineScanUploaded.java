
package com.dispatch.devicescan;

import java.time.Instant;

public record OfflineScanUploaded(
        String eventId,
        String aggregateId,
        int schemaVersion,
        Instant occurredAt,
        String correlationId,
        Long scanId,
        String shipmentId,
        String deviceId,
        Long sequenceNumber,
        String scanType,
        Instant deviceTimestamp
) {}
