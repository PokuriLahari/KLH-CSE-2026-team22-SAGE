
package com.dispatch.devicescan;

import java.time.Instant;
import java.time.ZoneId;
import java.util.UUID;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class ScanEventPublisher {

    public static final String TOPIC = "soa.s06.t22.events";

    private final KafkaTemplate<String, OfflineScanUploaded> kafkaTemplate;

    public ScanEventPublisher(
            KafkaTemplate<String, OfflineScanUploaded> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void publish(DeviceScan scan, String correlationId) {

        Instant deviceTime = scan.getDeviceTimestamp() == null
                ? null
                : scan.getDeviceTimestamp()
                      .atZone(ZoneId.systemDefault())
                      .toInstant();

        OfflineScanUploaded event = new OfflineScanUploaded(
                UUID.randomUUID().toString(),
                scan.getShipmentId(),
                1,
                Instant.now(),
                correlationId,
                scan.getId(),
                scan.getShipmentId(),
                scan.getDeviceId(),
                scan.getSequenceNumber(),
                scan.getScanType(),
                deviceTime
        );

        kafkaTemplate.send(TOPIC, scan.getShipmentId(), event);
    }
}
