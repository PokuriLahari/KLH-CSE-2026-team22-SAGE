package com.dispatch.devicescan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeviceScanServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
