// ========================================
// AUTH SERVICE URL
// ========================================

const AUTH_BASE = "http://localhost:8084";

const loginForm = document.getElementById("loginForm");
const signupForm = document.getElementById("signupForm");

// ========================================
// COMMON AUTH REQUEST FUNCTION
// ========================================

async function sendAuthRequest(endpoint, data, message, button) {
message.textContent = "";
button.disabled = true;
button.textContent =
button.id === "loginBtn" ? "Logging in..." : "Creating account...";

try {
    const response = await fetch(`${AUTH_BASE}${endpoint}`, {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(data)
    });

    const result = await response.json().catch(() => ({}));

    if (!response.ok) {
        throw new Error(
            result.message ||
            result.error ||
            `Request failed with status ${response.status}`
        );
    }

    return result;

} catch (error) {
    console.error("Authentication error:", error);

    message.textContent =
        error.message === "Failed to fetch"
            ? "Cannot connect to Auth Service. Check whether port 8084 is running."
            : error.message;

    message.style.color = "#dc2626";
    return null;

} finally {
    button.disabled = false;
    button.textContent =
        button.id === "loginBtn" ? "Login" : "Create Account";
}

}

// ========================================
// NORMALIZE ROLE
// ========================================

function normalizeRole(value) {
const role = String(value || "")
.trim()
.toUpperCase()
.replace(/^ROLE_/, "")
.replace(/[\s-]+/g, "_");

if (
    role === "COURIER"
) {
    return "COURIER";
}

if (
    role === "OPERATOR_REVIEWER" ||
    role === "OPERATORREVIEWER" ||
    role === "OPERATIONS_REVIEWER" ||
    role === "OPERATIONSREVIEWER" ||
    role === "REVIEWER"
) {
    return "OPERATOR_REVIEWER";
}

return role;

}

// ========================================
// LOGIN
// ========================================

if (loginForm) {
loginForm.addEventListener("submit", async function(event) {
event.preventDefault();

    const message = document.getElementById("message");
    const button = document.getElementById("loginBtn");

    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    const result = await sendAuthRequest(
        "/api/auth/login",
        {
            email: email,
            password: password
        },
        message,
        button
    );

    if (!result) {
        return;
    }

    // Validate JWT token
    if (!result.token) {
        message.textContent =
            "Login response did not contain a JWT token.";
        message.style.color = "#dc2626";
        return;
    }

    // Validate role returned by backend
    if (!result.role) {
        message.textContent =
            "Backend did not return a role. Check AuthController.";
        message.style.color = "#dc2626";
        return;
    }

    // Normalize backend role
    const role = normalizeRole(result.role);

    console.log("Backend role:", result.role);
    console.log("Normalized role:", role);

    // Save authentication details
    localStorage.setItem("dispatchflow_token", result.token);
    localStorage.setItem("dispatchflow_role", role);

    if (result.name) {
        localStorage.setItem("dispatchflow_name", result.name);
    }

    // Redirect only for supported roles
    if (
        role !== "COURIER" &&
        role !== "OPERATOR_REVIEWER"
    ) {
        message.textContent =
            "Unknown role returned by backend: " + result.role;
        message.style.color = "#dc2626";
        return;
    }

    message.textContent = "Login successful! Redirecting...";
    message.style.color = "#16a34a";

    setTimeout(function() {
        if (role === "COURIER") {
            window.location.href = "./courier-dashboard.html";
        } else {
            window.location.href = "./reviewer-dashboard.html";
        }
    }, 700);
});

}

// ========================================
// SIGNUP
// ========================================

if (signupForm) {
signupForm.addEventListener("submit", async function(event) {
event.preventDefault();

    const message = document.getElementById("message");
    const button = document.getElementById("signupBtn");

    const name = document.getElementById("name").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;
    const selectedRole = document.getElementById("role").value;

    const role = normalizeRole(selectedRole);

    if (!name || !email || password.length < 8) {
        message.textContent =
            "Enter your name, valid email, and password with at least 8 characters.";
        message.style.color = "#dc2626";
        return;
    }

    if (
        role !== "COURIER" &&
        role !== "OPERATOR_REVIEWER"
    ) {
        message.textContent = "Please select a valid role.";
        message.style.color = "#dc2626";
        return;
    }

    const result = await sendAuthRequest(
        "/api/auth/register",
        {
            name: name,
            email: email,
            password: password,
            role: role.toLowerCase()
        },
        message,
        button
    );

    if (!result) {
        return;
    }

    message.textContent =
        result.message || "Registration successful! Please login.";

    message.style.color = "#16a34a";
    signupForm.reset();
});

}