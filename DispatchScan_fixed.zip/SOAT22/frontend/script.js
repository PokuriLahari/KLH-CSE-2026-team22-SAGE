const API_BASE = "http://localhost:8080";

const $ = (id) => document.getElementById(id);


// ================================
// API HELPER
// ================================

async function api(url, options = {}) {
    const headers = { ...(options.headers || {}) };

    if (options.body) {
        headers["Content-Type"] = "application/json";
    }

    const token = localStorage.getItem("dispatchflow_token");

    if (token) {
        headers["Authorization"] = `Bearer ${token}`;
    }

    const response = await fetch(url, {
        ...options,
        headers
    });

    const text = await response.text();

    if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${text}`);
    }

    if (!text) {
        return null;
    }

    try {
        return JSON.parse(text);
    } catch {
        return text;
    }
}


// ================================
// DISPLAY MESSAGES
// ================================

function showMessage(message, type = "info") {
    const element = $("form-message");

    if (element) {
        element.textContent = message;

        element.style.color =
            type === "error" ? "red" :
            type === "success" ? "green" : "blue";
    }

    console.log(message);
}


// ================================
// NORMALIZE SCAN TYPE
// ================================

function normalizeScanType(value) {
    const type = String(value || "")
        .trim()
        .toUpperCase()
        .replace(/[\s-]+/g, "_");

    return type === "PICKED_UP" ? "LOADED" : type;
}


// ================================
// SIDEBAR NAVIGATION
// ================================

function showPage(pageName) {
    const selectedPage = $(pageName);

    if (!selectedPage) {
        console.error("Page not found:", pageName);
        return;
    }

    document.querySelectorAll(".page").forEach(page => {
        page.classList.remove("active");
        page.style.display = "none";
    });

    selectedPage.classList.add("active");
    selectedPage.style.display = "block";

    document.querySelectorAll(".nav-btn").forEach(button => {
        button.classList.toggle(
            "active",
            button.dataset.page === pageName
        );
    });

    const titles = {
        dashboard: "Operations Dashboard",
        upload: "Upload Scan",
        timeline: "Shipment Timeline",
        conflicts: "Conflict Review"
    };

    if ($("page-title")) {
        $("page-title").textContent =
            titles[pageName] || "DispatchFlow";
    }

    if (pageName === "dashboard") {
        refreshDashboard();
    }

    if (pageName === "timeline") {
        loadAllScans();
    }

    if (pageName === "conflicts") {
        loadConflicts();
    }
}


// ================================
// INITIALIZE APPLICATION
// ================================

document.addEventListener("DOMContentLoaded", () => {

    document.querySelectorAll("[data-page]").forEach(button => {
        button.addEventListener("click", () => {
            showPage(button.dataset.page);
        });
    });

    $("scan-form")?.addEventListener("submit", uploadScan);

    $("search-form")?.addEventListener("submit", searchTimeline);

    $("show-all-scans")?.addEventListener("click", loadAllScans);

    showPage("dashboard");
});


// ================================
// UPLOAD SCAN
// ================================

async function uploadScan(event) {
    event.preventDefault();

    const shipmentId = $("shipmentId").value.trim();
    const deviceId = $("deviceId").value.trim();
    const sequenceNumber = Number($("sequenceNumber").value);
    const scanType = normalizeScanType($("scanType").value);
    const deviceTimestamp = $("deviceTimestamp").value;

    if (
        !shipmentId ||
        !deviceId ||
        !scanType ||
        !deviceTimestamp ||
        !Number.isInteger(sequenceNumber) ||
        sequenceNumber < 1
    ) {
        showMessage("Please enter valid scan details.", "error");
        return;
    }

    const scan = {
        shipmentId,
        deviceId,
        sequenceNumber,
        scanType,
        deviceTimestamp
    };

    const button = $("scan-form").querySelector(
        'button[type="submit"]'
    );

    if (button) {
        button.disabled = true;
    }

    showMessage("Uploading scan...");

    try {
        // Save scan through API Gateway
        const saved = await api(`${API_BASE}/api/scans`, {
            method: "POST",
            body: JSON.stringify(scan)
        });

        // Show upload success independently of dashboard refresh
        showMessage(
            `Scan uploaded successfully! ${
                saved?.id != null ? "ID: " + saved.id : ""
            }`,
            "success"
        );

        $("scan-form").reset();

        // Refresh dashboard separately
        refreshDashboard().catch(error => {
            console.error("Dashboard refresh failed:", error);
        });

    } catch (error) {
        console.error("Scan upload failed:", error);

        showMessage(
            `Upload failed: ${error.message}`,
            "error"
        );

    } finally {
        if (button) {
            button.disabled = false;
        }
    }
}


// ================================
// EXTRACT ARRAYS FROM API RESPONSE
// ================================

function getArray(data) {
    if (Array.isArray(data)) {
        return data;
    }

    for (const key of [
        "content",
        "data",
        "scans",
        "events",
        "timeline",
        "conflicts"
    ]) {
        if (Array.isArray(data?.[key])) {
            return data[key];
        }
    }

    return [];
}


// ================================
// ESCAPE HTML
// ================================

function escapeHTML(value) {
    return String(value ?? "-").replace(/[&<>"']/g, char => ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#39;"
    })[char]);
}


// ================================
// FORMAT DATE AND TIME
// ================================

function formatTime(value) {
    if (!value) {
        return "-";
    }

    const date = new Date(value);

    return Number.isNaN(date.getTime())
        ? String(value)
        : date.toLocaleString();
}


// ================================
// DASHBOARD
// ================================

async function refreshDashboard() {
    try {
        const scans = getArray(
            await api(`${API_BASE}/api/scans`)
        );

        const recent = [...scans].reverse().slice(0, 8);

        if ($("recent-scans")) {
            $("recent-scans").innerHTML = recent.length
                ? recent.map(scan => `
                    <tr>
                        <td>${escapeHTML(scan.shipmentId)}</td>
                        <td>${escapeHTML(scan.deviceId)}</td>
                        <td>${escapeHTML(scan.sequenceNumber)}</td>
                        <td>${escapeHTML(scan.scanType)}</td>
                        <td>${escapeHTML(
                            formatTime(
                                scan.deviceTimestamp ?? scan.timestamp
                            )
                        )}</td>
                    </tr>
                `).join("")
                : `<tr><td colspan="5">No scans yet.</td></tr>`;
        }

        if ($("total-scans")) {
            $("total-scans").textContent = scans.length;
        }

        if ($("total-shipments")) {
            $("total-shipments").textContent =
                new Set(
                    scans
                        .map(scan => scan.shipmentId)
                        .filter(Boolean)
                ).size;
        }

    } catch (error) {
        console.error("Dashboard error:", error);
    }
}


// ================================
// SHIPMENT TIMELINE - ALL SCANS
// ================================

async function loadAllScans() {
    try {
        const scans = getArray(
            await api(`${API_BASE}/api/scans`)
        );

        renderTimeline(scans);

    } catch (error) {
        console.error("Timeline error:", error);
    }
}


// ================================
// RENDER TIMELINE
// ================================

function renderTimeline(scans) {
    if (!$("timeline-table")) {
        return;
    }

    $("timeline-table").innerHTML = scans.length
        ? scans.map(scan => `
            <tr>
                <td>${escapeHTML(scan.shipmentId)}</td>
                <td>${escapeHTML(scan.sequenceNumber)}</td>
                <td>${escapeHTML(scan.scanType)}</td>
                <td>${escapeHTML(scan.deviceId)}</td>
                <td>${escapeHTML(
                    formatTime(
                        scan.deviceTimestamp ?? scan.timestamp
                    )
                )}</td>
            </tr>
        `).join("")
        : `<tr><td colspan="5">No scans found.</td></tr>`;
}


// ================================
// SEARCH SHIPMENT TIMELINE
// ================================

function renderTimeline(scans) {
    if (!$("timeline-table")) {
        return;
    }

    // Group shipments and sort each shipment by sequence number
    const sortedScans = [...scans].sort((a, b) => {
        const shipmentA = String(a.shipmentId || "").toLowerCase();
        const shipmentB = String(b.shipmentId || "").toLowerCase();

        // Sort shipments by ID
        if (shipmentA < shipmentB) return -1;
        if (shipmentA > shipmentB) return 1;

        // Sort scans within each shipment: 1, 2, 3...
        return Number(a.sequenceNumber || 0) -
               Number(b.sequenceNumber || 0);
    });

    // Display sorted scans
    $("timeline-table").innerHTML = sortedScans.length
        ? sortedScans.map(scan => `
            <tr>
                <td>${escapeHTML(scan.shipmentId)}</td>
                <td>${escapeHTML(scan.sequenceNumber)}</td>
                <td>${escapeHTML(scan.scanType)}</td>
                <td>${escapeHTML(scan.deviceId)}</td>
                <td>${escapeHTML(
                    formatTime(scan.deviceTimestamp ?? scan.timestamp)
                )}</td>
            </tr>
        `).join("")
        : `<tr><td colspan="5">No scans found.</td></tr>`;
}

// ================================
// CONFLICT REVIEW
// ================================

async function loadConflicts() {
    try {
        const conflicts = getArray(
            await api(`${API_BASE}/api/conflicts`)
        );

        if ($("total-conflicts")) {
            $("total-conflicts").textContent = conflicts.length;
        }

        if ($("conflicts-table")) {
            $("conflicts-table").innerHTML = conflicts.length
                ? conflicts.map(conflict => `
                    <p>
                        Shipment: ${escapeHTML(conflict.shipmentId)}
                        — Status: ${escapeHTML(
                            conflict.status ?? conflict.reviewStatus
                        )}
                    </p>
                `).join("")
                : "No conflicts found.";
        }

    } catch (error) {
        console.error("Conflict loading error:", error);
    }
}