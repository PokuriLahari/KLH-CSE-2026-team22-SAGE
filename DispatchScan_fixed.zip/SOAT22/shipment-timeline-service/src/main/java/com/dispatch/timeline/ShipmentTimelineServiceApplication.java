package com.dispatch.timeline;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShipmentTimelineServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShipmentTimelineServiceApplication.class, args);
	}

}
