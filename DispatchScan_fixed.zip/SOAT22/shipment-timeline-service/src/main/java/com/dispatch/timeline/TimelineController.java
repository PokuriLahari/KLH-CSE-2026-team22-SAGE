
package com.dispatch.timeline;

import java.util.List;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/timeline")
@CrossOrigin(origins = "*")
public class TimelineController {

    private final TimelineEventRepository repository;

    public TimelineController(TimelineEventRepository repository) {
        this.repository = repository;
    }

    @GetMapping("/{shipmentId}")
    public List<TimelineEvent> getTimeline(
            @PathVariable String shipmentId) {

        return repository.findByShipmentIdOrderBySequenceNumberAsc(
                shipmentId);
    }
}
