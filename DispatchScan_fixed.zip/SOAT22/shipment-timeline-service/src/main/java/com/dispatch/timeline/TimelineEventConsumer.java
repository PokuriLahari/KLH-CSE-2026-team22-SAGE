package com.dispatch.timeline;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TimelineEventConsumer {

    private final TimelineEventRepository repository;
    private final ObjectMapper objectMapper;

    public TimelineEventConsumer(
            TimelineEventRepository repository,
            ObjectMapper objectMapper) {
        this.repository = repository;
        this.objectMapper = objectMapper;
    }

    @KafkaListener(
        topics = "soa.s06.t22.events",
        groupId = "shipment-timeline-group"
    )
    @Transactional
    public void consume(String message) throws Exception {

        JsonNode event = objectMapper.readTree(message);

        String eventId = event.path("eventId").asText();
        String shipmentId = event.path("shipmentId").asText();
        long sequence = event.path("sequenceNumber").asLong(-1);
        String scanType = event.path("scanType").asText();

        if (eventId.isBlank()
                || shipmentId.isBlank()
                || sequence < 1
                || scanType.isBlank()) {
            throw new IllegalArgumentException(
                    "Invalid OfflineScanUploaded event");
        }

        if (repository.existsByEventId(eventId)) {
            System.out.println("Duplicate event ignored: " + eventId);
            return;
        }

        TimelineEvent record = new TimelineEvent();
        record.setEventId(eventId);
        record.setShipmentId(shipmentId);
        record.setSequenceNumber(sequence);
        record.setScanType(scanType);
        record.setCorrelationId(
                event.path("correlationId").asText());

        try {
            repository.saveAndFlush(record);
            System.out.println(
                    "Timeline event saved: " + eventId);
        } catch (DataIntegrityViolationException ex) {
            // Another delivery may have inserted the same event.
            if (!repository.existsByEventId(eventId)) {
                throw ex;
            }
            System.out.println(
                    "Duplicate event ignored: " + eventId);
        }
    }
}