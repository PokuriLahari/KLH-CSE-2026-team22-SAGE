package com.dispatch.timeline;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TimelineEventRepository
        extends JpaRepository<TimelineEvent, Long> {

    boolean existsByEventId(String eventId);

    List<TimelineEvent>
        findByShipmentIdOrderBySequenceNumberAsc(String shipmentId);
}