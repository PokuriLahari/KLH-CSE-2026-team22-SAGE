package com.dispatch.timeline;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShipmentTimelineServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
